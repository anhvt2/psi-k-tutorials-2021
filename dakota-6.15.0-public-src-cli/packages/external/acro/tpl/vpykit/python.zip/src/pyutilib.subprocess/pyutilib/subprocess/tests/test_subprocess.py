import os
import sys
try:
    import StringIO
except:
    import io as StringIO
from os.path import abspath, dirname
currdir = dirname(abspath(__file__))+os.sep

import pyutilib.th as unittest
from nose.tools import nottest
import pyutilib.services
from pyutilib.subprocess import subprocess, SubprocessMngr, timer

try:
    import __pypy__
    is_pypy = True
except:
    is_pypy = False

pyutilib.services.register_executable("memmon")
pyutilib.services.register_executable("valgrind")

class Test(unittest.TestCase):

    def test_foo(self):
        if not subprocess.mswindows:
            foo = SubprocessMngr("ls *py > /tmp/.pyutilib", stdout=subprocess.PIPE, shell=True)
            foo.wait()
            print("")
            if os.path.exists("/tmp/.pyutilib"):
                os.remove("/tmp/.pyutilib")
        else:
            foo = SubprocessMngr("cmd /C \"dir\" > C:/tmp", shell=True)
            foo.wait()
            print("")

    @unittest.skipIf(is_pypy, "Cannot launch python in this test with pypy")
    def test_bar(self):
        stime = timer()
        # On MS Windows, do not run this in a shell.  If so, MS Windows has difficulty
        # killing the process after the timelimit
        print("Subprocess python process")
        sys.stdout.flush()
        foo = SubprocessMngr("python -q -c \"while True: pass\"", shell=not subprocess.mswindows)
        foo.wait(5)
        print("Ran for %f seconds" % (timer()-stime))

    @unittest.skipIf(subprocess.mswindows, "Cannot test the use of 'memmon' on MS Windows")
    @unittest.skipIf(sys.platform == 'darwin', "Cannot test the use of 'memmon' on Darwin")
    @unittest.skipIf(pyutilib.services.registered_executable('memmon') is None, "The 'memmon' executable is not available.")
    def test_memmon(self):
        pyutilib.services.register_executable('ls')
        pyutilib.subprocess.run(pyutilib.services.registered_executable('ls').get_path()+' *.py', memmon=True, outfile=currdir+'ls.out')
        INPUT = open(currdir+'ls.out','r')
        flag = False
        for line in INPUT:
            flag = line.startswith('memmon:')
            if flag:
                break
        INPUT.close()
        if not flag:
            self.fail("Failed to properly execute 'memmon' with the 'ls' command")
        os.remove(currdir+'ls.out')

    @unittest.skipIf(subprocess.mswindows, "Cannot test the use of 'valgrind' on MS Windows")
    @unittest.skipIf(pyutilib.services.registered_executable('valgrind') is None, "The 'valgrind' executable is not available.")
    def test_valgrind(self):
        pyutilib.services.register_executable('ls')
        pyutilib.subprocess.run(pyutilib.services.registered_executable('ls').get_path()+' *.py', valgrind=True, outfile=currdir+'valgrind.out')
        INPUT = open(currdir+'valgrind.out','r')
        flag = False
        for line in INPUT:
            flag = 'Memcheck' in line
            if flag:
                break
        INPUT.close()
        if not flag:
            self.fail("Failed to properly execute 'valgrind' with the 'ls' command")
        os.remove(currdir+'valgrind.out')
        
    def test_outputfile(self):
        pyutilib.subprocess.run([sys.executable, currdir+"tee_script.py"], outfile=currdir+'tee.out')
        self.assertFileEqualsBaseline(currdir+'tee.out', currdir+'tee.txt')

    def test_ostream_stringio(self):
        script_out = StringIO.StringIO()
        output = pyutilib.subprocess.run( 
            [sys.executable, currdir+"tee_script.py"], ostream=script_out )
        self.assertEquals( "Tee Script: ERR\nTee Script: OUT\n",
                           script_out.getvalue() )
                           

    def test_tee(self):
        stream_out = StringIO.StringIO()
        script_out = StringIO.StringIO()
        pyutilib.misc.setup_redirect(stream_out)
        output = pyutilib.subprocess.run(
            [sys.executable, currdir+"tee_script.py"], 
            ostream=script_out, tee=True )
        pyutilib.misc.reset_redirect()
        self.assertEquals( stream_out.getvalue(), script_out.getvalue() )
        self.assertTrue( stream_out.getvalue() in 
                         ( "Tee Script: ERR\nTee Script: OUT\n",
                           "Tee Script: OUT\nTee Script: ERR\n" ) )
        self.assertTrue( script_out.getvalue() in 
                         ( "Tee Script: ERR\nTee Script: OUT\n",
                           "Tee Script: OUT\nTee Script: ERR\n" ) )

    def test_tee_stdout(self):
        stream_out = StringIO.StringIO()
        script_out = StringIO.StringIO()
        pyutilib.misc.setup_redirect(stream_out)
        output = pyutilib.subprocess.run(
            [sys.executable, currdir+"tee_script.py"], 
            ostream=script_out, tee=(True, False) )
        pyutilib.misc.reset_redirect()
        self.assertEquals( "Tee Script: OUT\n", 
                           stream_out.getvalue() )
        self.assertTrue( script_out.getvalue() in 
                         ( "Tee Script: ERR\nTee Script: OUT\n",
                           "Tee Script: OUT\nTee Script: ERR\n" ) )

    def test_tee_stderr(self):
        stream_out = StringIO.StringIO()
        script_out = StringIO.StringIO()
        pyutilib.misc.setup_redirect(stream_out)
        output = pyutilib.subprocess.run(
            [sys.executable, currdir+"tee_script.py"], 
            ostream=script_out, tee=(False, True) )
        pyutilib.misc.reset_redirect()
        self.assertEquals( "Tee Script: ERR\n", 
                           stream_out.getvalue() )
        self.assertTrue( script_out.getvalue() in 
                         ( "Tee Script: ERR\nTee Script: OUT\n",
                           "Tee Script: OUT\nTee Script: ERR\n" ) )


if __name__ == "__main__":
    unittest.main()

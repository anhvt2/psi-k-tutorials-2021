#
# This generates a load error
#
#from pyutilib.component.core import *
#from pyutilib.component.config import *

class test4_foo(Plugin):

    abc = Option("x1")

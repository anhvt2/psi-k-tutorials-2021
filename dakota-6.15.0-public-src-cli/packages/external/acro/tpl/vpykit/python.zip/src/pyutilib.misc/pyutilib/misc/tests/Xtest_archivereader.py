#
# Unit Tests for misc/archivereader
#
#

import os
import sys
from os.path import abspath, dirname, join

from nose.tools import nottest
import unittest

from pyutilib.misc.archivereader import *

currdir = os.path.dirname(os.path.abspath(__file__))
testdatadir = currdir


class TestArchiveReaderFactory(unittest.TestCase):

    def test_ArchiveReaderFactory_dir(self):
        archive = ArchiveReaderFactory(join(testdatadir,'archive'))
        self.assertTrue(isinstance(archive, DirArchiveReader))

    def test_ArchiveReaderFactory_tar(self):
        archive = ArchiveReaderFactory(join(testdatadir,'archive.tar'))
        self.assertTrue(isinstance(archive, TarArchiveReader))

    def test_ArchiveReaderFactory_targz(self):
        archive = ArchiveReaderFactory(join(testdatadir,'archive.tar.gz'))
        self.assertTrue(isinstance(archive, TarArchiveReader))

    def test_ArchiveReaderFactory_tgz(self):
        archive = ArchiveReaderFactory(join(testdatadir,'archive.tgz'))
        self.assertTrue(isinstance(archive, TarArchiveReader))

    @unittest.skipIf(sys.version_info[:2] < (2,6), "Skipping due to unsupported zipfile module in python < 2.6")
    def test_ArchiveReaderFactory_zip(self):
        archive = ArchiveReaderFactory(join(testdatadir,'archive.zip'))
        self.assertTrue(isinstance(archive, ZipArchiveReader))

    @unittest.skipIf(sys.version_info[:2] < (2,7), "Skipping due to bug in python 2.5 and 2.6")
    def test_ArchiveReaderFactory_file(self):
        try:
            archive = ArchiveReaderFactory(join(testdatadir,'archive.txt'))
        except ValueError:
            pass
        else:
            self.fail("ArchiveReaderFactory should raise exception with nonarchived files")

    def test_ArchiveReaderFactory_nonexist(self):
        try:
            archive = ArchiveReaderFactory(join(testdatadir,'_does_not_exist_'))
        except IOError:
            pass
        else:
            self.fail("ArchiveReaderFactory should raise exception with nonexistent archive")


def _test_open_file_object(self):
    self.archive.open_file_object('file1.txt')
    self.assertEqual(str(self.archive.file().read()),
                     "File 1: This Test Passed\n")
    self.archive.open_file_object('file2.txt')
    self.assertEqual(str(self.archive.file().read()),
                     "File 2: This Test Passed\n")
    
def _test_contains_file(self):
    self.assertTrue(self.archive.contains_file('file1.txt'))
    self.assertTrue(self.archive.contains_file('file2.txt'))

def _test_get_filelist(self):
    flist = self.archive.get_filelist()
    if '.svn' in flist:
        # For the test case where the archive is a plain directory
        flist.remove('.svn')
    if '' in flist:
        flist.remove('')
    self.assertEqual(sorted(['file1.txt','file2.txt']), sorted(flist))


class TestDirArchiveReader(unittest.TestCase):
    
    # This method is called once, before all tests are executed.
    @classmethod
    def setUpClass(self):
        self.archive_name = 'archive'
        self.archive = ArchiveReaderFactory(join(testdatadir,self.archive_name))

    def test_open_file_object(self):
        _test_open_file_object(self)
    def test_contains_file(self):
        _test_contains_file(self)
    def test_get_filelist(self):
        _test_get_filelist(self)
    

class TestTarArchiveReader1(unittest.TestCase):
    
    # This method is called once, before all tests are executed.
    @classmethod
    def setUpClass(self):
        self.archive_name = 'archive.tar'
        self.archive = ArchiveReaderFactory(join(testdatadir,self.archive_name))

    def test_open_file_object(self):
        _test_open_file_object(self)
    def test_contains_file(self):
        _test_contains_file(self)
    def test_get_filelist(self):
        _test_get_filelist(self)


class TestTarArchiveReader2(unittest.TestCase):
    
    # This method is called once, before all tests are executed.
    @classmethod
    def setUpClass(self):
        self.archive_name = 'archive.tar.gz'
        self.archive = ArchiveReaderFactory(join(testdatadir,self.archive_name))

    def test_open_file_object(self):
        _test_open_file_object(self)
    def test_contains_file(self):
        _test_contains_file(self)
    def test_get_filelist(self):
        _test_get_filelist(self)


class TestTarArchiveReader3(unittest.TestCase):
    
    # This method is called once, before all tests are executed.
    @classmethod
    def setUpClass(self):
        self.archive_name = 'archive.tgz'
        self.archive = ArchiveReaderFactory(join(testdatadir,self.archive_name))

    def test_open_file_object(self):
        _test_open_file_object(self)
    def test_contains_file(self):
        _test_contains_file(self)
    def test_get_filelist(self):
        _test_get_filelist(self)


class TestZipArchiveReader(unittest.TestCase):
    
    # This method is called once, before all tests are executed.
    @classmethod
    def setUpClass(self):
        self.archive_name = 'archive.zip'
        if sys.version_info[:2] >= (2,6):
            self.archive = ArchiveReaderFactory(join(testdatadir,self.archive_name))

    def test_open_file_object(self):
        _test_open_file_object(self)
    def test_contains_file(self):
        _test_contains_file(self)
    def test_get_filelist(self):
        _test_get_filelist(self)

TestZipArchiveReader = unittest.skipIf(sys.version_info[:2] < (2,6), "Skipping due to unsupported zipfile module in python < 2.6")(TestZipArchiveReader)


#FIXME: The 'with' statement is a syntax error on python 2.5 so we can't test this
"""
class TestArchiveReader(unittest.TestCase):
    
    @unittest.skipIf(sys.version_info[:2] < (2,6))
    def test_with(self):
        for archive_name in ['archive', 'archive.tar', 'archive.tar.gz', 'archive.tgz', 'archive.zip']:
            fp = None
            with ArchiveReaderFactory(join(testdatadir,archive_name)) as archive:
                archive.open_file_object('file1.txt')
                fp = archive.file()
            self.assertEqual(fp.closed, True)
"""

if __name__ == "__main__":
    unittest.main()


This directory contains a working pyutilib.autotest example that will
execute on Linux platforms.

example.yml - The YAML test configuration
example.py  - The test driver plugin
autotest.py - The Python module that executes tests

